import{b as a,c as b}from"./chunk-M2X7KQLB.js";import"./chunk-FBFWB55K.js";export{a as GESTURE_CONTROLLER,b as createGesture};
