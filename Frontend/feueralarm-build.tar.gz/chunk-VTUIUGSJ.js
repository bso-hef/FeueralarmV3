import{a}from"./chunk-E7ZOKENL.js";import"./chunk-FBFWB55K.js";export{a as startFocusVisible};
