const { exception } = require("console");

module.exports = (req, res, next) => {
  try {
    let role = req.userData.role;
    if (role && role == "admin")
      next();
    else throw exception();
  } catch (error) {
    res.status(401).json({message: "You have no permission!"});
  }
}
