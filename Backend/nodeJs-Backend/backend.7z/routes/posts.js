const express = require("express");

const checkAuth = require("../middleware/check-auth");
const checkPermission = require("../middleware/check-permission");
const PostController = require("../controllers/posts")

const router = express.Router();

// router.post("", checkAuth, checkPermission, PostController.addPost);
router.put("/:id", checkAuth, checkPermission, PostController.updatePost);
router.post("/alert", checkAuth, checkPermission, PostController.alert);
router.get("", checkAuth, PostController.fetchPosts);
router.get("/:id", checkAuth, PostController.fetchPost);
router.delete("/:id", checkAuth, checkPermission, PostController.deletePost);

module.exports = router;
