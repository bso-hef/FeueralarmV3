const Post = require("../models/post");
const untis = require("../untis/requests");

exports.alert = async (req, res) => { 
  try {
    if (! await untis.getUntisSession()) {
      res.status(500).json({
        message: "Authentication to Untis failed."
      });    
    }
  
    let teachers = await untis.getTeachers();
    if (!teachers) {
      res.status(500).json({
        message: "Loading Teachers from Untis failed."
      });   
    }

    let classes = await untis.getClasses();
    if (!classes) {
      res.status(500).json({
        message: "Loading Classes from Untis failed."
      });   
    }

    let rooms = await untis.getRooms();
    if (!rooms) {
      res.status(500).json({
        message: "Loading Rooms from Untis failed."
      }); 
    }

    let date = new Date();    
    date.setHours(date.getHours() + 2);
    day = date.getFullYear() * 10000 + (date.getMonth() + 1) * 100 + date.getDate();        
    if (req.query.day) day = req.query.day;

    let time = date.getHours() * 100 + date.getMinutes();
    if (req.query.time && req.query.time > 0 && req.query.time < 2400)
    time = req.query.time; 

    posts = await untis.getPostsMultiThreaded(teachers, classes, rooms, day, time);
    posts = untis.getProcessedPostList(posts);
    if (!posts) {
      res.status(500).json({
        message: "Creating Posts failed."
      });   
    }    

    // if (posts) {      
    //   res.status(201).json({
    //     message: "Creating Posts succeeded.",
    //     posts
    //   }); 
    //   return;
    // }        

    Post.deleteMany({})
    .then(result => {            
      Post.create(posts)
      .then(createdPosts => {        
        res.status(201).json({
          message: 'Posts loaded successfully',          
          count: createdPosts.length         
        });
      })
      .catch(error => {
        res.status(500).json({
          message: "Loading posts failed.",
          err: error.message
        })
      });
    })
    .catch(error => {
      res.status(500).json({
        message: "Deleting posts failed!"
      })
    });
  }
  catch (error) {
    res.status(500).json({
      message: "Something went horribly wrong.",
      err: error.message
    })
  }  
}

function getDummyData() {
  let time = new Date();
  time.setHours(time.getHours() + 2);
  let posts = [];
  for (let i = 0; i < 10; i++) {
    posts.push(new Post({
      class: "Klasse " + i,
      teachers: ["Lehrer1", "Lehrer2"],
      comments: ["Kommentar1", "Kommentar2"],
      status: "undefined",
      created: time,
      updated: time
    }));
  }
  return posts;
}

exports.updatePost = (req, res, next) => {
  Post.findById(req.params.id)
  .then(post => {
    let time = new Date();
    time.setHours(time.getHours() + 2);

    let updatedPost = post;

    if (req.body.status && (req.body.status == "invalid" ||
    req.body.status == "complete" || req.body.status == "incomplete")) {
      updatedPost.status = req.body.status;
      updatedPost.updated = time;
    }

    if (req.body.comment) {
      updatedPost.comment = req.body.comment;
      updatedPost.updated = time;
    }

    Post.updateOne({ _id: req.params.id}, updatedPost)
    .then(result => {
      if (result.n > 0) {
        res.status(201).json({message: "Update successful!" , post: JSON.parse(JSON.stringify(updatedPost))});
      } else {
        res.status(401).json({message: "Post not found!" });
      }
    })
    .catch(error => {
      res.status(500).json({
        message: "Could not update post!",
        err: error.message
      })
    });
  })
  .catch(err => {
    res.status(500).json({
      message: "Post not found!"
    })
  });

}

exports.fetchPosts = (req, res, next) => {
  Post.find().sort({ class: 1 })
  .then(fetchedPosts => {
    res.status(201).json({
      message: 'Posts fetched successfully',
      posts: fetchedPosts
    });
  })
  .catch(error => {
    res.status(500).json({
      message: "Fetching posts failed!",
      err: error.message
    })
  });
}

exports.fetchPost = (req, res, next) => {
  Post.findById(req.params.id)
  .then(post => {
    if (post) {
      res.status(201).json({
        message: "Post was found!",
        post: post
      });
    } else {
      res.status(404).json({mesage: "Post not found!"});
    }
  })
  .catch(error => {
    res.status(500).json({
      message: "Fetching post failed!"
    })
  });
}

exports.deletePost = (req, res, next) => {
  Post.deleteOne({_id: req.params.id})
    .then(result => {
      if (result.n > 0) {
        res.status(201).json({message: "Post deleted!" });
      } else {
        res.status(401).json({message: "Post not found!" });
      }
    })
    .catch(error => {
      res.status(500).json({
        message: "Deleting post failed!"
      })
    });
}
