const { parentPort, workerData, isMainThread } = require("worker_threads");
const Post = require("../models/post");
const axios = require("axios");

if (!isMainThread && workerData) {
    doWork(workerData);
}

async function doWork(data) {
    let posts = [];
    try {
        let url = data.requestURL;
        let header = data.requestHeader;
        let body = data.timetableBody;
        let teachers = data.teachers;
        let classes = data.classes;
        let rooms = data.rooms;
        let day = data.day;
        let time = data.time;

        for (let clas in workerData.workLoad) {
            body.params.id = clas;
            body.params.startDate = day;
            body.params.endDate = day;  
                  
            let res = await axios.post(url, body, header);            
            let teachersOfLesson = {};
            let acceptedTime = null;
            let acceptedLesson = null;
            if (res.data && res.data.result) {
                for (lesson of res.data.result) { 
                    if ((lesson.startTime >= time && (lesson.startTime - time) <= 15) ||
                        (lesson.endTime > time && lesson.startTime < time)) {                                                     
                        if (!acceptedTime && !acceptedLesson) {
                            acceptedTime = lesson.startTime;                                                    
                        }

                        if (lesson.startTime != acceptedTime) break;

                        acceptedLesson = lesson;
                        for (let teacher of acceptedLesson.te) {
                            teachersOfLesson[teacher.id] = null;                            
                        }
                    }                    
                }         
                
                //console.log(acceptedLesson);

                if (Object.keys(teachersOfLesson).length > 0) {
                    let className = classes[clas];
                        
                    let teacherNames = [];
                    for (let teacher in teachersOfLesson) {
                        teacherNames.push(teachers[teacher].foreName + " " +
                            teachers[teacher].lastName);
                    }

                    let roomNames = [];
                    for (let room of acceptedLesson.ro) {
                        let id;
                        if (room.orgid) id = room.orgid;
                        else id = room.id;

                        roomNames.push({
                            number: rooms[id].name,
                            name: rooms[id].longName
                        });
                    }

                    let createdTime = new Date();
                    createdTime.setHours(createdTime.getHours() + 2);

                    let post = {
                        class: className,
                        teachers: teacherNames,
                        rooms: roomNames,
                        comment: "",
                        start: acceptedLesson.startTime,
                        end: acceptedLesson.endTime,
                        day,
                        status: "undefined",
                        created: createdTime,
                        updated: createdTime
                    };

                    posts.push(post);    
                }
            }
        }        
        parentPort.postMessage({ message: "finished", posts});
    }
    catch (error) {
        console.log(error.message);
        parentPort.postMessage({ message: error}); 
    }
}